import PricesContainer from "./PricesContainer";
export default PricesContainer;
