import MarketsContainer from "./MarketsContainer";
export default MarketsContainer;
