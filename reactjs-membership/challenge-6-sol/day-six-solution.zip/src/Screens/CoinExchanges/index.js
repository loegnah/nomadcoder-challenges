import CoinExchangesContainer from "./CoinExchangesContainer";

export default CoinExchangesContainer;
