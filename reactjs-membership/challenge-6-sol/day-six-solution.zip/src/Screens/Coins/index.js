import CoinsContainer from "./CoinsContainer";
export default CoinsContainer;
